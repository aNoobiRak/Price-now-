package com.example.pricecompare

import android.annotation.SuppressLint
import android.app.*
import android.app.job.JobParameters
import android.app.job.JobService
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.net.URLEncoder

class P(val price: Int, val title: String, val url: String, val img: String = "")

object Core {
    // Добавить магазин = одна строка здесь
    val stores = listOf(
        "Ozon" to { q: String -> "https://www.ozon.ru/search/?text=$q&from_global=true" },
        "Wildberries" to { q: String -> "https://www.wildberries.ru/catalog/0/search.aspx?search=$q" },
        "Яндекс Маркет" to { q: String -> "https://market.yandex.ru/search?text=$q" },
        "DNS" to { q: String -> "https://www.dns-shop.ru/search/?q=$q" },
        "Ситилинк" to { q: String -> "https://www.citilink.ru/search/?text=$q" },
        "Мегамаркет" to { q: String -> "https://megamarket.ru/catalog/?q=$q" }
    )

    // Аксессуары не считаем тем же товаром
    private val ACC = Regex("(?i)чехол|кейс|ремешок|кабель|плёнк|пленк|защитн|стекл|держател|подставк|картридж|футляр|сумк")

    // Собирает ВСЕ карточки со страницы, где в тексте есть модель (без пробелов и дефисов), с ценой, ссылкой и фото
    private val STORE_JS = """(function(keys){
var re=/^\s*(?:от\s*)?\d[\d\s\u00a0\u2009]*\s*₽\s*$/;
var sel='span,div,p,b,ins,strong';
var bad=/по вашему запросу|поиск по|ничего не найден/i;
function cp(s){return (s||'').toLowerCase().replace(/[\s\-]+/g,'')}
function ok(x){return x.childElementCount<=3&&re.test(x.textContent)}
function has(s){var t=cp(s);return keys.every(function(k){return t.indexOf(k)>=0})}
var els=document.querySelectorAll(sel),seen=[],out=[];
for(var i=0;i<els.length&&out.length<12;i++){
 if(!ok(els[i]))continue;
 var c=els[i];
 for(var k=0;k<10&&c.parentElement;k++){
  c=c.parentElement;
  var raw=c.innerText||'';
  if(raw.length>2500)break;
  if(!c.querySelector('a[href]')&&!(c.closest&&c.closest('a[href]')))continue;
  if(!has(raw))continue;
  if(bad.test(raw))break;
  if(seen.indexOf(c)>=0)break;
  seen.push(c);
  var m=[],ps=c.querySelectorAll(sel);
  for(var j=0;j<ps.length;j++)if(ok(ps[j]))m.push(parseInt(ps[j].textContent.replace(/\D/g,'')));
  if(!m.length)break;
  var links=c.querySelectorAll('a[href]'),a=null;
  for(var j=0;j<links.length&&!a;j++){
   if(has((links[j].innerText||'')+(links[j].getAttribute('aria-label')||'')+(links[j].title||'')))a=links[j]}
  if(!a)a=links[0]||c.closest('a[href]');
  var ls=raw.split('\n');
  var t=ls.filter(function(l){return has(l)})[0]||ls[0];
  var im=c.querySelector('img');
  out.push({p:Math.min.apply(null,m),t:t.slice(0,100),u:a?a.href:'',
   i:im?(im.currentSrc||im.src||im.getAttribute('data-src')||''):''});
  break;
 }
}
return out.length?JSON.stringify({c:out}):'';})"""

    // Карточка исходного товара: название, фото, цена
    val PAGE_JS = """(function(){var o={t:'',p:'',i:''};
document.querySelectorAll('script[type="application/ld+json"]').forEach(function(s){try{
var j=JSON.parse(s.textContent);(Array.isArray(j)?j:[j]).forEach(function(x){if(x['@type']=='Product'){
o.t=x.name||o.t;var im=x.image;o.i=Array.isArray(im)?im[0]:(im||o.i);
var f=x.offers;if(f){f=Array.isArray(f)?f[0]:f;o.p=String(f.price||f.lowPrice||o.p)}}})}catch(e){}});
function m(n){var e=document.querySelector('meta[property="'+n+'"]');return e?e.content:''}
if(!o.t)o.t=m('og:title')||document.title;
if(!o.i)o.i=m('og:image');
if(!o.p){var re=/^\s*\d[\d\s\u00a0\u2009]*\s*₽\s*$/;var els=document.querySelectorAll('span,div');
for(var i=0;i<els.length;i++){if(els[i].children.length<=1&&re.test(els[i].textContent)){o.p=els[i].textContent.replace(/\D/g,'');break}}}
if(!o.t&&!o.p)return '';
return JSON.stringify(o);})()"""

    // Что показала страница, если цену найти не удалось: сайт, число цен, есть ли модель, размер карточки
    private val DIAG_FN = """(function(keys){var b=((document.body&&document.body.innerText)||'');
function cp(s){return (s||'').toLowerCase().replace(/[\s\-]+/g,'')}
var re=/^\s*(?:от\s*)?\d[\d\s]*\s*₽\s*$/;var n=0,L='нет';
var els=document.querySelectorAll('span,div,p,b,ins,strong');
for(var i=0;i<els.length;i++){var x=els[i];
if(!(x.childElementCount<=3&&re.test(x.textContent)))continue;n++;
if(L!='нет')continue;var c=x;
for(var k=0;k<14&&c.parentElement;k++){c=c.parentElement;var t=cp(c.innerText);
if(keys.every(function(q){return t.indexOf(q)>=0})){L=t.length+(c.querySelector('a[href]')?' со ссылкой':' без ссылки');break}}}
return location.host+' | цен: '+n+' | модель: '+keys.every(function(k){return cp(b).indexOf(k)>=0})+
' | карточка: '+L+' | '+b.replace(/\s+/g,' ').slice(0,60)})"""

    fun enc(q: String): String = URLEncoder.encode(q, "UTF-8")

    fun clean(t: String) = t.replace(Regex("(?i)\\s+купить.*$"), "")
        .replace(Regex("(?i)\\s*[-—|].*ozon.*$"), "").trim()

    // Из длинного названия берём бренд + модель: «Hyundai HMEO 6580 DX»
    fun query(title: String): String {
        val t = title.replace(Regex("[,;()]"), " ").split(Regex("\\s+")).filter { it.isNotEmpty() }
        val i = t.indexOfFirst { Regex("[A-Za-z]").containsMatchIn(it) }
        if (i < 0) return t.take(6).joinToString(" ")
        val m = t.drop(i).takeWhile { Regex("^[A-Za-z0-9\\-./]+$").matches(it) }.take(5)
        return if (m.size >= 2) m.joinToString(" ") else t.take(6).joinToString(" ")
    }

    // По чему проверяем, что в карточке тот же товар: слово перед первым числом + число («flip6», «hmeo6580»)
    fun keys(q: String): List<String> {
        val t = q.lowercase().replace("-", "").split(Regex("\\s+")).filter { it.isNotEmpty() }
        val i = t.indexOfFirst { w -> w.any { it.isDigit() } }
        if (i >= 0) return listOf((if (i > 0) t[i - 1] else "") + t[i])
        return t.filter { it.length > 3 }.take(2).ifEmpty { t }
    }

    @SuppressLint("SetJavaScriptEnabled")
    fun web(ctx: Context, hidden: Boolean = true): WebView =
        WebView(if (hidden) ctx.applicationContext else ctx).also {
            it.settings.javaScriptEnabled = true
            it.settings.domStorageEnabled = true
            if (hidden) it.layout(0, 0, 1080, 1920)
        }

    // Открывает страницу в скрытом WebView; первые scrolls проходов прокручивает вниз (подгружает карточки),
    // потом опрашивает скрипт, пока он не вернёт данные
    fun run(
        ctx: Context, url: String, script: String, tries: Int,
        diag: String = DIAG_FN + "([])", scrolls: Int = 0, cb: (JSONObject?, String) -> Unit
    ) {
        val h = Handler(Looper.getMainLooper())
        val wv = web(ctx)
        var n = 0
        var fin = false
        fun end(o: JSONObject?, d: String = "") { if (fin) return; fin = true; wv.destroy(); cb(o, d) }
        fun fail() {
            if (fin) return
            wv.evaluateJavascript(diag) { r -> end(null, (JSONTokener(r).nextValue() as? String).orEmpty()) }
        }
        fun poll() {
            h.postDelayed({
                if (fin) return@postDelayed
                if (n < scrolls) {
                    wv.evaluateJavascript("window.scrollBy(0,3000)", null)
                    n++; poll()
                } else wv.evaluateJavascript(script) { r ->
                    val raw = (JSONTokener(r).nextValue() as? String).orEmpty()
                    if (raw.isNotEmpty()) end(JSONObject(raw)) else if (++n < tries) poll() else fail()
                }
            }, 3000)
        }
        wv.webViewClient = object : WebViewClient() {
            var started = false
            override fun onPageFinished(v: WebView, u: String) { if (!started) { started = true; poll() } }
        }
        h.postDelayed({ fail() }, 50000)
        wv.loadUrl(url)
    }

    // Из всех карточек берём самую дешёвую, не считая аксессуаров и цен, далёких от цены исходного товара
    fun fetch(ctx: Context, url: String, q: String, src: Int?, cb: (P?, String) -> Unit) {
        val ks = JSONArray(keys(q)).toString()
        run(ctx, url, STORE_JS + "(" + ks + ")", 8, DIAG_FN + "(" + ks + ")", 2) { o, d ->
            val arr = o?.optJSONArray("c")
            if (arr == null) cb(null, d)
            else {
                val all = ArrayList<P>()
                for (i in 0 until arr.length()) {
                    val x = arr.getJSONObject(i)
                    val p = x.optString("p").toIntOrNull() ?: continue
                    val u = x.optString("u")
                    all.add(P(p, x.optString("t"), if (u.startsWith("http")) u else url, x.optString("i")))
                }
                val items = all.filter { !ACC.containsMatchIn(it.title) }
                val sorted = items.map { it.price }.sorted()
                val base = src ?: if (sorted.isEmpty()) 0 else sorted[sorted.size / 2]
                val good = items.filter { it.price >= base * 0.3 && (src == null || it.price <= base * 4) }
                val best = good.minByOrNull { it.price }
                cb(best, if (best == null) "карточки есть, но это аксессуары или цена не подходит" else "")
            }
        }
    }
}

// История: массив {q, h:[[время, магазин, цена], ...]}
object Tracker {
    private fun sp(c: Context) = c.getSharedPreferences("t", 0)
    fun load(c: Context) = JSONArray(sp(c).getString("items", "[]"))
    private fun save(c: Context, a: JSONArray) = sp(c).edit().putString("items", a.toString()).apply()

    fun add(c: Context, q: String) {
        val a = load(c)
        for (i in 0 until a.length()) if (a.getJSONObject(i).getString("q") == q) return
        a.put(JSONObject().put("q", q).put("h", JSONArray())); save(c, a)
    }

    fun remove(c: Context, q: String) {
        val a = load(c)
        for (i in 0 until a.length()) if (a.getJSONObject(i).getString("q") == q) { a.remove(i); break }
        save(c, a)
    }

    // Записывает цену, возвращает предыдущую цену этого магазина
    fun record(c: Context, q: String, store: String, price: Int): Int? {
        val a = load(c)
        var prev: Int? = null
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.getString("q") != q) continue
            val h = o.getJSONArray("h")
            for (j in h.length() - 1 downTo 0) {
                val e = h.getJSONArray(j)
                if (e.getString(1) == store) { prev = e.getInt(2); break }
            }
            h.put(JSONArray().put(System.currentTimeMillis()).put(store).put(price))
            if (h.length() > 300) {
                val n = JSONArray()
                for (j in h.length() - 300 until h.length()) n.put(h.get(j))
                o.put("h", n)
            }
        }
        save(c, a)
        return prev
    }

    fun notify(c: Context, q: String, store: String, old: Int, new: Int) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("p", "Цены", NotificationManager.IMPORTANCE_DEFAULT))
        val what = if (new < old) "↓ подешевел" else "↑ подорожал"
        val n = Notification.Builder(c, "p").setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("$q: $what").setContentText("$store: $old → $new ₽").setAutoCancel(true).build()
        nm.notify((q + store).hashCode(), n)
    }
}

// Фоновая проверка раз в 6 часов
class PriceJob : JobService() {
    override fun onStartJob(p: JobParameters): Boolean {
        val items = Tracker.load(this)
        var left = items.length() * Core.stores.size
        if (left == 0) return false
        for (i in 0 until items.length()) {
            val q = items.getJSONObject(i).getString("q")
            for ((name, build) in Core.stores) Core.fetch(this, build(Core.enc(q)), q, null) { r, _ ->
                if (r != null) {
                    val old = Tracker.record(this, q, name, r.price)
                    if (old != null && old != r.price) Tracker.notify(this, q, name, old, r.price)
                }
                if (--left == 0) jobFinished(p, false)
            }
        }
        return true
    }
    override fun onStopJob(p: JobParameters) = true
}
