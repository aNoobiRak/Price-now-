package com.example.pricecompare

import android.annotation.SuppressLint
import android.app.*
import android.app.job.JobParameters
import android.app.job.JobService
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.net.URLEncoder

class P(val price: Int, val title: String, val url: String)

object Core {
    // Добавить магазин = одна строка здесь
    val stores = listOf(
        "Wildberries" to { q: String -> "https://www.wildberries.ru/catalog/0/search.aspx?search=$q" },
        "Яндекс Маркет" to { q: String -> "https://market.yandex.ru/search?text=$q" },
        "DNS" to { q: String -> "https://www.dns-shop.ru/search/?q=$q" }
    )

    private const val UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"

    // Общий скрипт: первая цена в рублях на странице и название рядом с ней
    private val JS = """(function(){var re=/^\s*(?:от\s*)?\d[\d\s\u00a0\u2009]*\s*₽\s*$/;
var els=document.querySelectorAll('span,div,p,b,ins');
for(var i=0;i<els.length;i++){var e=els[i];if(e.children.length>1)continue;var t=e.textContent;
if(re.test(t)){var c=e;for(var k=0;k<6&&c.parentElement;k++){c=c.parentElement;
if(c.querySelector('a[href]')&&c.innerText.length>25)break;}
var a=c.querySelector('a[href]');
return JSON.stringify({p:t.replace(/[^\d]/g,''),t:(c.innerText||'').split('\n')[0].slice(0,80),u:a?a.href:''});}}
return '';})()"""

    fun enc(q: String): String = URLEncoder.encode(q, "UTF-8")

    @SuppressLint("SetJavaScriptEnabled")
    private fun web(ctx: Context): WebView = WebView(ctx.applicationContext).also {
        it.settings.javaScriptEnabled = true
        it.settings.domStorageEnabled = true
        it.settings.userAgentString = UA
        it.layout(0, 0, 1080, 1920)
    }

    fun title(ctx: Context, url: String, cb: (String) -> Unit) {
        val wv = web(ctx)
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, u: String) {
                Handler(Looper.getMainLooper()).postDelayed({
                    v.evaluateJavascript("document.title") { r ->
                        val t = (JSONTokener(r).nextValue() as? String).orEmpty()
                            .replace(Regex("(?i)\\s*[-—|].*ozon.*$"), "").trim()
                        v.destroy(); cb(t)
                    }
                }, 2500)
            }
        }
        wv.loadUrl(url)
    }

    fun fetch(ctx: Context, url: String, cb: (P?) -> Unit) {
        val h = Handler(Looper.getMainLooper())
        val wv = web(ctx)
        var tries = 0
        var finished = false
        fun end(p: P?) { if (finished) return; finished = true; wv.destroy(); cb(p) }
        fun poll() {
            h.postDelayed({
                if (!finished) wv.evaluateJavascript(JS) { r ->
                    val raw = (JSONTokener(r).nextValue() as? String).orEmpty()
                    val o = if (raw.isNotEmpty()) JSONObject(raw) else null
                    val price = o?.optString("p")?.toIntOrNull()
                    if (o != null && price != null) {
                        val u = o.optString("u")
                        end(P(price, o.optString("t"), if (u.startsWith("http")) u else url))
                    } else if (++tries < 4) poll() else end(null)
                }
            }, 3000)
        }
        wv.webViewClient = object : WebViewClient() {
            var started = false
            override fun onPageFinished(v: WebView, u: String) { if (!started) { started = true; poll() } }
        }
        h.postDelayed({ end(null) }, 25000)
        wv.loadUrl(url)
    }
}

// История: массив {q, h:[[время, магазин, цена], ...]}
object Tracker {
    private fun sp(c: Context) = c.getSharedPreferences("t", 0)
    fun load(c: Context) = JSONArray(sp(c).getString("items", "[]"))
    private fun save(c: Context, a: JSONArray) = sp(c).edit().putString("items", a.toString()).apply()

    fun add(c: Context, q: String) {
        val a = load(c)
        for (i in 0 until a.length()) if (a.getJSONObject(i).getString("q") == q) return
        a.put(JSONObject().put("q", q).put("h", JSONArray())); save(c, a)
    }

    fun remove(c: Context, q: String) {
        val a = load(c)
        for (i in 0 until a.length()) if (a.getJSONObject(i).getString("q") == q) { a.remove(i); break }
        save(c, a)
    }

    // Записывает цену, возвращает предыдущую цену этого магазина
    fun record(c: Context, q: String, store: String, price: Int): Int? {
        val a = load(c)
        var prev: Int? = null
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.getString("q") != q) continue
            val h = o.getJSONArray("h")
            for (j in h.length() - 1 downTo 0) {
                val e = h.getJSONArray(j)
                if (e.getString(1) == store) { prev = e.getInt(2); break }
            }
            h.put(JSONArray().put(System.currentTimeMillis()).put(store).put(price))
            if (h.length() > 300) {
                val n = JSONArray()
                for (j in h.length() - 300 until h.length()) n.put(h.get(j))
                o.put("h", n)
            }
        }
        save(c, a)
        return prev
    }

    fun notify(c: Context, q: String, store: String, old: Int, new: Int) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("p", "Цены", NotificationManager.IMPORTANCE_DEFAULT))
        val what = if (new < old) "↓ подешевел" else "↑ подорожал"
        val n = Notification.Builder(c, "p").setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("$q: $what").setContentText("$store: $old → $new ₽").setAutoCancel(true).build()
        nm.notify((q + store).hashCode(), n)
    }
}

// Фоновая проверка раз в 6 часов
class PriceJob : JobService() {
    override fun onStartJob(p: JobParameters): Boolean {
        val items = Tracker.load(this)
        var left = items.length() * Core.stores.size
        if (left == 0) return false
        for (i in 0 until items.length()) {
            val q = items.getJSONObject(i).getString("q")
            for ((name, build) in Core.stores) Core.fetch(this, build(Core.enc(q))) { r ->
                if (r != null) {
                    val old = Tracker.record(this, q, name, r.price)
                    if (old != null && old != r.price) Tracker.notify(this, q, name, old, r.price)
                }
                if (--left == 0) jobFinished(p, false)
            }
        }
        return true
    }
    override fun onStopJob(p: JobParameters) = true
}
