package com.example.pricecompare

import android.annotation.SuppressLint
import android.app.*
import android.app.job.JobParameters
import android.app.job.JobService
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.net.URLEncoder

class P(val price: Int, val title: String, val url: String)

object Core {
    // Добавить магазин = одна строка здесь
    val stores = listOf(
        "Wildberries" to { q: String -> "https://www.wildberries.ru/catalog/0/search.aspx?search=$q" },
        "Яндекс Маркет" to { q: String -> "https://market.yandex.ru/search?text=$q" },
        "DNS" to { q: String -> "https://www.dns-shop.ru/search/?q=$q" }
    )

    private const val UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"

    // Ищет карточку, в тексте которой есть ключи (модель), и берёт в ней минимальную цену
    private val STORE_JS = """(function(keys){
var re=/^\s*(?:от\s*)?\d[\d\s\u00a0\u2009]*\s*₽\s*$/;
var sel='span,div,p,b,ins,strong';
var els=document.querySelectorAll(sel);
function ok(x){return x.children.length<=1&&re.test(x.textContent)}
for(var i=0;i<els.length;i++){
 if(!ok(els[i]))continue;
 var c=els[i];
 for(var k=0;k<8&&c.parentElement;k++){
  c=c.parentElement;
  var tx=(c.innerText||'').toLowerCase();
  if(tx.length>700)break;
  if(!c.querySelector('a[href]'))continue;
  if(!keys.every(function(x){return tx.indexOf(x)>=0}))continue;
  var m=[];var ps=c.querySelectorAll(sel);
  for(var j=0;j<ps.length;j++)if(ok(ps[j]))m.push(parseInt(ps[j].textContent.replace(/\D/g,'')));
  var ls=(c.innerText||'').split('\n');
  var t=ls.filter(function(l){return l.toLowerCase().indexOf(keys[0])>=0})[0]||ls[0];
  return JSON.stringify({p:Math.min.apply(null,m),t:t.slice(0,100),u:c.querySelector('a[href]').href});
 }
}
return '';})"""

    // Карточка исходного товара: название, фото, цена
    val PAGE_JS = """(function(){var o={t:'',p:'',i:''};
document.querySelectorAll('script[type="application/ld+json"]').forEach(function(s){try{
var j=JSON.parse(s.textContent);(Array.isArray(j)?j:[j]).forEach(function(x){if(x['@type']=='Product'){
o.t=x.name||o.t;var im=x.image;o.i=Array.isArray(im)?im[0]:(im||o.i);
var f=x.offers;if(f){f=Array.isArray(f)?f[0]:f;o.p=String(f.price||f.lowPrice||o.p)}}})}catch(e){}});
function m(n){var e=document.querySelector('meta[property="'+n+'"]');return e?e.content:''}
if(!o.t)o.t=m('og:title')||document.title;
if(!o.i)o.i=m('og:image');
if(!o.p){var re=/^\s*\d[\d\s\u00a0\u2009]*\s*₽\s*$/;var els=document.querySelectorAll('span,div');
for(var i=0;i<els.length;i++){if(els[i].children.length<=1&&re.test(els[i].textContent)){o.p=els[i].textContent.replace(/\D/g,'');break}}}
if(!o.t&&!o.p)return '';
return JSON.stringify(o);})()"""

    fun enc(q: String): String = URLEncoder.encode(q, "UTF-8")

    fun clean(t: String) = t.replace(Regex("(?i)\\s+купить.*$"), "")
        .replace(Regex("(?i)\\s*[-—|].*ozon.*$"), "").trim()

    // Из длинного названия берём бренд + модель: «Hyundai HMEO 6580 DX»
    fun query(title: String): String {
        val t = title.replace(Regex("[,;()]"), " ").split(Regex("\\s+")).filter { it.isNotEmpty() }
        val i = t.indexOfFirst { Regex("[A-Za-z]").containsMatchIn(it) }
        if (i < 0) return t.take(6).joinToString(" ")
        val m = t.drop(i).takeWhile { Regex("^[A-Za-z0-9\\-./]+$").matches(it) }.take(5)
        return if (m.size >= 2) m.joinToString(" ") else t.take(6).joinToString(" ")
    }

    // По каким словам проверяем, что в выдаче тот же товар
    fun keys(q: String): List<String> {
        val t = q.lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val d = t.filter { w -> w.any { it.isDigit() } && w.length >= 3 }
        return d.ifEmpty { t.filter { it.length > 3 }.take(2) }.ifEmpty { t }
    }

    @SuppressLint("SetJavaScriptEnabled")
    fun web(ctx: Context, hidden: Boolean = true): WebView =
        WebView(if (hidden) ctx.applicationContext else ctx).also {
            it.settings.javaScriptEnabled = true
            it.settings.domStorageEnabled = true
            it.settings.userAgentString = UA
            if (hidden) it.layout(0, 0, 1080, 1920)
        }

    // Открывает страницу в скрытом WebView и опрашивает скрипт, пока он не вернёт данные
    fun run(ctx: Context, url: String, script: String, tries: Int, cb: (JSONObject?) -> Unit) {
        val h = Handler(Looper.getMainLooper())
        val wv = web(ctx)
        var n = 0
        var fin = false
        fun end(o: JSONObject?) { if (fin) return; fin = true; wv.destroy(); cb(o) }
        fun poll() {
            h.postDelayed({
                if (fin) return@postDelayed
                wv.evaluateJavascript(script) { r ->
                    val raw = (JSONTokener(r).nextValue() as? String).orEmpty()
                    if (raw.isNotEmpty()) end(JSONObject(raw)) else if (++n < tries) poll() else end(null)
                }
            }, 3000)
        }
        wv.webViewClient = object : WebViewClient() {
            var started = false
            override fun onPageFinished(v: WebView, u: String) { if (!started) { started = true; poll() } }
        }
        h.postDelayed({ end(null) }, 45000)
        wv.loadUrl(url)
    }

    fun fetch(ctx: Context, url: String, q: String, cb: (P?) -> Unit) {
        val script = STORE_JS + "(" + JSONArray(keys(q)).toString() + ")"
        run(ctx, url, script, 6) { o ->
            val p = o?.optString("p")?.toIntOrNull()
            if (o == null || p == null) cb(null)
            else {
                val u = o.optString("u")
                cb(P(p, o.optString("t"), if (u.startsWith("http")) u else url))
            }
        }
    }
}

// История: массив {q, h:[[время, магазин, цена], ...]}
object Tracker {
    private fun sp(c: Context) = c.getSharedPreferences("t", 0)
    fun load(c: Context) = JSONArray(sp(c).getString("items", "[]"))
    private fun save(c: Context, a: JSONArray) = sp(c).edit().putString("items", a.toString()).apply()

    fun add(c: Context, q: String) {
        val a = load(c)
        for (i in 0 until a.length()) if (a.getJSONObject(i).getString("q") == q) return
        a.put(JSONObject().put("q", q).put("h", JSONArray())); save(c, a)
    }

    fun remove(c: Context, q: String) {
        val a = load(c)
        for (i in 0 until a.length()) if (a.getJSONObject(i).getString("q") == q) { a.remove(i); break }
        save(c, a)
    }

    // Записывает цену, возвращает предыдущую цену этого магазина
    fun record(c: Context, q: String, store: String, price: Int): Int? {
        val a = load(c)
        var prev: Int? = null
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.getString("q") != q) continue
            val h = o.getJSONArray("h")
            for (j in h.length() - 1 downTo 0) {
                val e = h.getJSONArray(j)
                if (e.getString(1) == store) { prev = e.getInt(2); break }
            }
            h.put(JSONArray().put(System.currentTimeMillis()).put(store).put(price))
            if (h.length() > 300) {
                val n = JSONArray()
                for (j in h.length() - 300 until h.length()) n.put(h.get(j))
                o.put("h", n)
            }
        }
        save(c, a)
        return prev
    }

    fun notify(c: Context, q: String, store: String, old: Int, new: Int) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("p", "Цены", NotificationManager.IMPORTANCE_DEFAULT))
        val what = if (new < old) "↓ подешевел" else "↑ подорожал"
        val n = Notification.Builder(c, "p").setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("$q: $what").setContentText("$store: $old → $new ₽").setAutoCancel(true).build()
        nm.notify((q + store).hashCode(), n)
    }
}

// Фоновая проверка раз в 6 часов
class PriceJob : JobService() {
    override fun onStartJob(p: JobParameters): Boolean {
        val items = Tracker.load(this)
        var left = items.length() * Core.stores.size
        if (left == 0) return false
        for (i in 0 until items.length()) {
            val q = items.getJSONObject(i).getString("q")
            for ((name, build) in Core.stores) Core.fetch(this, build(Core.enc(q)), q) { r ->
                if (r != null) {
                    val old = Tracker.record(this, q, name, r.price)
                    if (old != null && old != r.price) Tracker.notify(this, q, name, old, r.price)
                }
                if (--left == 0) jobFinished(p, false)
            }
        }
        return true
    }
    override fun onStopJob(p: JobParameters) = true
}
