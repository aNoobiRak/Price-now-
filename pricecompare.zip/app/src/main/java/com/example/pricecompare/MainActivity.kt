package com.example.pricecompare

import android.app.Activity
import android.app.AlertDialog
import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date

class MainActivity : Activity() {

    private class Res(var status: String, var p: P? = null, val url: String)

    private val res = LinkedHashMap<String, Res>()
    private var cur = ""
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private lateinit var watch: Button
    private lateinit var tracked: LinearLayout

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        input = EditText(this).apply { hint = "Название товара или ссылка" }
        val btn = Button(this).apply { text = "Искать"; setOnClickListener { handle(input.text.toString()) } }
        status = TextView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        watch = Button(this).apply {
            text = "Следить за ценой"; visibility = android.view.View.GONE
            setOnClickListener { startWatch() }
        }
        val head = TextView(this).apply { text = "\nОтслеживаемые"; textSize = 18f }
        tracked = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listOf(input, btn, status, list, watch, head, tracked).forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        val js = getSystemService(JobScheduler::class.java)
        if (js.getPendingJob(1) == null) js.schedule(
            JobInfo.Builder(1, ComponentName(this, PriceJob::class.java))
                .setPeriodic(6 * 3600 * 1000L)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true).build()
        )
        renderTracked()
        intent?.takeIf { it.action == Intent.ACTION_SEND }
            ?.getStringExtra(Intent.EXTRA_TEXT)?.let { input.setText(it); handle(it) }
    }

    private fun handle(text: String) {
        val urlRe = Regex("https?://\\S+")
        val url = urlRe.find(text)?.value
        val q = text.replace(urlRe, "").trim()
        if (q.length >= 3) return search(q)
        if (url == null) { status.text = "Нужно название или ссылка"; return }
        val slug = Regex("/product/([^/?]+)").find(url)?.groupValues?.get(1)
            ?.replace(Regex("-\\d+$"), "")?.replace('-', ' ')
        if (!slug.isNullOrBlank()) return search(slug)
        status.text = "Читаю название товара…"
        Core.title(this, url) { t ->
            if (t.length >= 3) { input.setText(t); search(t) }
            else status.text = "Не удалось прочитать название, введи его вручную"
        }
    }

    private fun search(q: String) {
        cur = q
        status.text = "Ищу: $q"
        watch.visibility = android.view.View.GONE
        res.clear()
        var left = Core.stores.size
        for ((name, build) in Core.stores) {
            val url = build(Core.enc(q))
            res[name] = Res("ищу…", url = url)
            Core.fetch(this, url) { r ->
                res[name]?.apply { p = r; status = if (r == null) "цену получить не удалось" else "ok" }
                renderResults()
                if (--left == 0 && res.values.any { it.p != null }) watch.visibility = android.view.View.VISIBLE
            }
        }
        renderResults()
    }

    private fun renderResults() {
        list.removeAllViews()
        val sorted = res.entries.sortedWith(compareBy({ it.value.p == null }, { it.value.p?.price }))
        val best = sorted.firstOrNull()?.value?.p?.price
        for ((name, r) in sorted) {
            val p = r.p
            list.addView(TextView(this).apply {
                textSize = 16f; setPadding(0, 24, 0, 24)
                text = if (p != null) "$name: ${money(p.price)}" + (if (p.price == best) "  ← дешевле всех" else "") + "\n${p.title}"
                else "$name: ${r.status}"
                setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(p?.url ?: r.url))) }
            })
        }
    }

    private fun startWatch() {
        Tracker.add(this, cur)
        for ((name, r) in res) r.p?.let { Tracker.record(this, cur, name, it.price) }
        watch.visibility = android.view.View.GONE
        status.text = "Слежу: $cur. Проверка раз в несколько часов"
        renderTracked()
    }

    private fun money(v: Int) = "%,d".format(v).replace(',', ' ') + " ₽"

    private fun renderTracked() {
        tracked.removeAllViews()
        val a = Tracker.load(this)
        val fmt = SimpleDateFormat("dd.MM HH:mm")
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val q = o.getString("q"); val h = o.getJSONArray("h")
            val first = HashMap<String, Int>(); val last = LinkedHashMap<String, Int>()
            for (j in 0 until h.length()) {
                val e = h.getJSONArray(j)
                first.getOrPut(e.getString(1)) { e.getInt(2) }; last[e.getString(1)] = e.getInt(2)
            }
            val lines = last.map { (n, p) ->
                val d = p - first[n]!!
                "$n: ${money(p)}" + if (d != 0) (if (d < 0) "  ↓" else "  ↑") + money(Math.abs(d)) else ""
            }
            tracked.addView(TextView(this).apply {
                textSize = 15f; setPadding(0, 20, 0, 20)
                text = q + "\n" + lines.joinToString("\n")
                setOnClickListener {
                    val hist = (h.length() - 1 downTo 0).joinToString("\n") { j ->
                        val e = h.getJSONArray(j)
                        "${fmt.format(Date(e.getLong(0)))}  ${e.getString(1)}  ${money(e.getInt(2))}"
                    }
                    AlertDialog.Builder(this@MainActivity).setTitle(q)
                        .setMessage(hist.ifEmpty { "Пока пусто" })
                        .setPositiveButton("Закрыть", null)
                        .setNeutralButton("Не следить") { _, _ -> Tracker.remove(this@MainActivity, q); renderTracked() }
                        .show()
                }
            })
        }
    }
}
