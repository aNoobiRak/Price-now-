package com.example.pricecompare

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.webkit.WebViewClient
import android.widget.*
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date

class MainActivity : Activity() {

    private class Res(var status: String, var p: P? = null, val url: String)

    private val res = LinkedHashMap<String, Res>()
    private var cur = ""
    private var srcTitle = ""
    private var srcPrice: Int? = null
    private var srcUrl = ""
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var card: LinearLayout
    private lateinit var pic: ImageView
    private lateinit var cardText: TextView
    private lateinit var list: LinearLayout
    private lateinit var watch: Button
    private lateinit var tracked: LinearLayout

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        input = EditText(this).apply { hint = "Название товара или ссылка" }
        val btn = Button(this).apply { text = "Искать"; setOnClickListener { handle(input.text.toString()) } }
        status = TextView(this)
        card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; visibility = View.GONE; setPadding(0, 24, 0, 24)
            setOnClickListener { askPrice() }
        }
        pic = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        cardText = TextView(this).apply { textSize = 15f; setPadding(24, 0, 0, 0) }
        card.addView(pic, LinearLayout.LayoutParams(280, 280))
        card.addView(cardText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        watch = Button(this).apply {
            text = "Следить за ценой"; visibility = View.GONE
            setOnClickListener { startWatch() }
        }
        val head = TextView(this).apply { text = "\nОтслеживаемые"; textSize = 18f }
        tracked = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listOf(input, btn, status, card, list, watch, head, tracked).forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        val js = getSystemService(JobScheduler::class.java)
        if (js.getPendingJob(1) == null) js.schedule(
            JobInfo.Builder(1, ComponentName(this, PriceJob::class.java))
                .setPeriodic(6 * 3600 * 1000L)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true).build()
        )
        renderTracked()
        intent?.takeIf { it.action == Intent.ACTION_SEND }
            ?.getStringExtra(Intent.EXTRA_TEXT)?.let { input.setText(it); handle(it) }
    }

    private fun handle(text: String) {
        val urlRe = Regex("https?://\\S+")
        val url = urlRe.find(text)?.value
        val title = text.replace(urlRe, "").trim()
        srcUrl = url ?: ""; srcTitle = if (url != null) title else ""; srcPrice = null
        pic.setImageDrawable(null); showCard(); renderResults()
        if (url != null) loadCard(url, title.length < 3)
        if (title.length >= 3) search(Core.query(title))
        else if (url == null) status.text = "Нужно название или ссылка"
        else status.text = "Читаю товар…"
    }

    private fun srcName() = if (srcUrl.contains("ozon")) "Ozon" else "исходном магазине"

    private fun loadCard(url: String, needSearch: Boolean) {
        Core.run(this, url, Core.PAGE_JS, 3) { o, _ ->
            if (o != null) {
                if (srcTitle.length < 3) srcTitle = Core.clean(o.optString("t"))
                srcPrice = o.optString("p").toIntOrNull()
                loadImg(o.optString("i"), pic)
            }
            showCard(); renderResults()
            if (needSearch) {
                if (srcTitle.length >= 3) { input.setText(srcTitle); search(Core.query(srcTitle)) }
                else status.text = "Не удалось прочитать товар, введи название вручную"
            }
        }
    }

    private fun showCard() {
        if (srcUrl.isEmpty()) { card.visibility = View.GONE; return }
        card.visibility = View.VISIBLE
        cardText.text = (if (srcTitle.isEmpty()) "Загружаю…" else srcTitle) + "\n" +
            (srcPrice?.let { money(it) } ?: "цену не нашёл — нажми, чтобы ввести") + "\n" +
            srcName().replaceFirstChar { it.uppercase() }
    }

    private fun askPrice() {
        val e = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; hint = "Цена, ₽" }
        AlertDialog.Builder(this).setTitle("Цена на ${srcName()}").setView(e)
            .setPositiveButton("Ок") { _, _ ->
                srcPrice = e.text.toString().toIntOrNull(); showCard(); renderResults()
            }
            .setNegativeButton("Отмена", null).show()
    }

    private fun search(q: String) {
        cur = q
        status.text = "Ищу: $q"
        watch.visibility = View.GONE
        res.clear()
        for ((name, build) in Core.stores) res[name] = Res("ищу…", url = build(Core.enc(q)))
        var left = res.size
        for (name in res.keys.toList()) fetchStore(name) {
            if (--left == 0 && res.values.any { it.p != null }) watch.visibility = View.VISIBLE
        }
        renderResults()
    }

    private fun fetchStore(name: String, done: () -> Unit = {}) {
        val r = res[name] ?: return
        r.status = "ищу…"; r.p = null; renderResults()
        Core.fetch(this, r.url, cur, srcPrice) { p, d ->
            r.p = p
            r.status = if (p != null) "ok"
            else if (d.contains("по вашему запросу", true) || d.contains("ничего не найден", true)) "в магазине такого товара нет"
            else "не нашёл (${d.ifEmpty { "страница не загрузилась" }})\nнажми, чтобы открыть магазин"
            renderResults(); done()
        }
    }

    // Магазин в окне приложения: можно пройти капчу, потом цена запрашивается заново
    private fun openStore(name: String, url: String) {
        val d = Dialog(this, android.R.style.Theme_DeviceDefault_Light)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val wv = Core.web(this, false)
        wv.webViewClient = WebViewClient()
        wv.loadUrl(url)
        val b = Button(this).apply { text = "Готово — обновить цену"; setOnClickListener { d.dismiss() } }
        box.addView(b)
        box.addView(wv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        d.setContentView(box)
        d.setOnDismissListener { wv.destroy(); fetchStore(name) }
        d.show()
    }

    private fun renderResults() {
        list.removeAllViews()
        val sorted = res.entries.sortedWith(compareBy({ it.value.p == null }, { it.value.p?.price }))
        val src = srcPrice
        val bestP = sorted.firstOrNull()?.value?.p?.price
        if (bestP != null && src != null) list.addView(TextView(this).apply {
            textSize = 16f; setPadding(0, 16, 0, 16)
            text = if (bestP < src) "Дешевле всего: ${sorted.first().key} — на ${money(src - bestP)} дешевле, чем по ссылке"
            else "По ссылке не дороже, чем в найденных магазинах"
        })
        for ((name, r) in sorted) {
            val p = r.p
            val d = if (p != null && src != null) p.price - src else null
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; setPadding(0, 24, 0, 24)
                setOnClickListener {
                    if (p != null) startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(p.url)))
                    else openStore(name, r.url)
                }
            }
            if (p != null) {
                val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
                row.addView(iv, LinearLayout.LayoutParams(200, 200))
                loadImg(p.img, iv)
            }
            row.addView(TextView(this).apply {
                textSize = 16f; setPadding(if (p != null) 24 else 0, 0, 0, 0)
                text = if (p != null) {
                    "$name: ${money(p.price)}" +
                        (if (d != null && d != 0) "  (${if (d > 0) "+" else "−"}${money(Math.abs(d))})" else "") +
                        (if (p.price == bestP && (src == null || p.price < src)) "  ← дешевле всех" else "") +
                        "\n${p.title}"
                } else "$name: ${r.status}"
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            list.addView(row)
        }
    }

    private val imgCache = HashMap<String, android.graphics.Bitmap>()

    private fun loadImg(u0: String, iv: ImageView) {
        val u = if (u0.startsWith("//")) "https:$u0" else u0
        if (!u.startsWith("http")) return
        imgCache[u]?.let { iv.setImageBitmap(it); return }
        Thread {
            try {
                val b = BitmapFactory.decodeStream(URL(u).openStream())
                runOnUiThread { imgCache[u] = b; iv.setImageBitmap(b) }
            } catch (e: Exception) {}
        }.start()
    }

    private fun startWatch() {
        Tracker.add(this, cur)
        for ((name, r) in res) r.p?.let { Tracker.record(this, cur, name, it.price) }
        watch.visibility = View.GONE
        status.text = "Слежу: $cur. Проверка раз в несколько часов"
        renderTracked()
    }

    private fun money(v: Int) = "%,d".format(v).replace(',', ' ') + " ₽"

    private fun renderTracked() {
        tracked.removeAllViews()
        val a = Tracker.load(this)
        val fmt = SimpleDateFormat("dd.MM HH:mm")
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val q = o.getString("q"); val h = o.getJSONArray("h")
            val first = HashMap<String, Int>(); val last = LinkedHashMap<String, Int>()
            for (j in 0 until h.length()) {
                val e = h.getJSONArray(j)
                first.getOrPut(e.getString(1)) { e.getInt(2) }; last[e.getString(1)] = e.getInt(2)
            }
            val lines = last.map { (n, p) ->
                val d = p - first[n]!!
                "$n: ${money(p)}" + if (d != 0) (if (d < 0) "  ↓" else "  ↑") + money(Math.abs(d)) else ""
            }
            tracked.addView(TextView(this).apply {
                textSize = 15f; setPadding(0, 20, 0, 20)
                text = q + "\n" + lines.joinToString("\n")
                setOnClickListener {
                    val hist = (h.length() - 1 downTo 0).joinToString("\n") { j ->
                        val e = h.getJSONArray(j)
                        "${fmt.format(Date(e.getLong(0)))}  ${e.getString(1)}  ${money(e.getInt(2))}"
                    }
                    AlertDialog.Builder(this@MainActivity).setTitle(q)
                        .setMessage(hist.ifEmpty { "Пока пусто" })
                        .setPositiveButton("Закрыть", null)
                        .setNeutralButton("Не следить") { _, _ -> Tracker.remove(this@MainActivity, q); renderTracked() }
                        .show()
                }
            })
        }
    }
}
